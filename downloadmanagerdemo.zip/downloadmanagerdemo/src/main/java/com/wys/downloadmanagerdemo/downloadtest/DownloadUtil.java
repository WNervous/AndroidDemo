package com.wys.downloadmanagerdemo.downloadtest;

public class DownloadUtil {

    public void downloadFile(String url) {

    }

    public void setOnDownloadListener(IOnDownloadListener mListener) {
    }
}
