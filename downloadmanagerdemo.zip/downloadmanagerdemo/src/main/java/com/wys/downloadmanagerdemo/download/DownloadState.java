package com.wys.downloadmanagerdemo.download;

public enum  DownloadState {
     STATE_DOWLOAIDNG,
     STATE_FAILED,
     STATE_SUCCESS
}
